import java.util.Scanner;

//Используйте for.
//Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
// Пользователь указывает нижнюю и верхнюю границу диапазона.
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Пожалуйста введите два числа : ");
        int a = scn.nextInt();
        int b = scn.nextInt();
        int sum = 0;
        for (int i = a; i <=b; i++){
            if (i % 2 ==1){
                sum += 1;
            }
        }
        System.out.println("Сумма нечетных чисел в диапозоне от " + a + " до " + b + " = " + sum);
    }
}