import java.util.Scanner;

//Используйте foreach.
//Дан Enum месяцев. Пользователь вводит имя текущего месяца в консоль.
// Программа должна вывести все месяцы, кроме того, что ввёл пользователь.
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Пожалуйста, введите имя текущего месяца : ");
        String month = scn.nextLine().toUpperCase();
        Month month1 = Month.valueOf(month);
        for (Month mon : Month.values()){
            if (month1 != mon){
                System.out.println(mon.name() + " ");
            }
        }
    }
}